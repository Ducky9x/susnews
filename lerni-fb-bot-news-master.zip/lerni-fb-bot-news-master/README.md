# Our community
Group facebook: https://www.facebook.com/groups/lerni/

Youtube channel: https://www.youtube.com/channel/UCvVwR21Pb8r06LcZ7n3eR4g
# Folder structor
```
├── news                    
│   ├── vnexpress.js        # crawler data from vnexpress
├── app.js                  # main application
├── create-image.js         # create image from news
├── facebook.js             # Api Facebook
└── ...
```
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/namttdh/lerni-fb-bot-news)
